BLOCKWORLDS — DEMO WEBSITE
==========================

Dateien:
- index.html: Website-Inhalt
- style.css: dunkles, responsives Design
- script.js: mobiles Menü und Demo-Kaufdialog
- assets/blockworlds-design-preview.png: Design-Vorschau (falls vorhanden)

LOKAL ANSEHEN
Öffne index.html in einem Browser.

KOSTENLOS VERÖFFENTLICHEN MIT GITHUB PAGES
1. Erstelle mit Hilfe deiner Eltern ein GitHub-Konto, falls nötig.
2. Lege ein neues öffentliches Repository an, z. B. blockworlds.
3. Lade index.html, style.css, script.js und den assets-Ordner hoch.
4. Öffne im Repository Settings → Pages.
5. Wähle „Deploy from a branch“, Branch „main“ und Ordner „/(root)“, dann Save.
6. Warte, bis GitHub Pages die Website veröffentlicht hat. Die URL wird im Pages-Bereich angezeigt.

WICHTIG ZUM VERKAUF
Diese Website ist aktuell nur eine statische Vorlage. Es werden KEINE echten Zahlungen verarbeitet und KEINE Downloads ausgeliefert.
Für echte Verkäufe:
- Ersetze die Beispielkarten, Beispielpreise und Beispielbilder durch deine eigenen Inhalte.
- Hinterlege für jedes Produkt einen echten Checkout-Link bei einem passenden Zahlungs-/Shop-Anbieter.
- Richte sichere digitale Downloads ein.
- Prüfe Gebühren, Rückerstattungen, Steuern und Plattformregeln.
- Ergänze vor einem echten Verkauf die gesetzlich erforderlichen Anbieter-/Kontaktangaben, Datenschutz- und Verbraucherinformationen.
- Wenn du minderjährig bist, lass deine Eltern die Konten, Verträge und Zahlungsabwicklung prüfen und gegebenenfalls übernehmen.

Die Website ist nicht mit Mojang oder Microsoft verbunden. Minecraft ist eine Marke von Mojang Studios.
