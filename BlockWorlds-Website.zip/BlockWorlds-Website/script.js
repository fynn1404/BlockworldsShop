const nav = document.getElementById('nav');
document.getElementById('menuToggle').addEventListener('click', () => nav.classList.toggle('open'));
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));
let cartCount = 0;
const modal = document.getElementById('modal');
const modalTitle = document.getElementById('modalTitle');
const modalText = document.getElementById('modalText');
function closeModal(){ modal.hidden = true; }
document.getElementById('closeModal').addEventListener('click', closeModal);
document.getElementById('modalOk').addEventListener('click', closeModal);
modal.addEventListener('click', e => { if(e.target === modal) closeModal(); });
document.querySelectorAll('.buy').forEach(button => button.addEventListener('click', () => {
  const name = button.dataset.product;
  const price = Number(button.dataset.price).toLocaleString('de-DE', {style:'currency',currency:'EUR'});
  modalTitle.textContent = name;
  modalText.textContent = `Beispielpreis: ${price}. Dieser Demo-Shop verarbeitet noch keine Zahlungen. Füge später einen echten Checkout-Link und den sicheren Download für diese Map hinzu.`;
  modal.hidden = false;
}));
